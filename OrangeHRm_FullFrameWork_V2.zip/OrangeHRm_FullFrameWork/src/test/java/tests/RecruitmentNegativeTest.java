package tests;

import org.testng.Assert;
import org.testng.annotations.Test;
import pages.RecruitmentPage;

public class RecruitmentNegativeTest extends TestBase {

    @Test(priority = 2)
    public void adminCannotAddCandidateWithMissingFields() throws InterruptedException {
        RecruitmentPage recruitmentPage = new RecruitmentPage(driver);

        recruitmentPage.addCandidateWithMissingFields();
        
        Thread.sleep(2000);

        Assert.assertTrue(recruitmentPage.requiredErrorMsg.isDisplayed(),
                "Error message 'Required' should appear!");
    }
}