package tests;

import org.testng.Assert;
import org.testng.annotations.Test;
import pages.RecruitmentPage;

public class RecruitmentHappyTest extends TestBase {

    @Test(priority = 1)
    public void adminCanAddCandidateSuccessfully() throws InterruptedException {
        RecruitmentPage recruitmentPage = new RecruitmentPage(driver);

        recruitmentPage.addCandidateSuccessfully();
        
        Thread.sleep(2000); 
        
        Assert.assertTrue(recruitmentPage.successMsg.getText().contains("Success"),
                 "Successfully Saved");
    }
}