package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class AddEmployeePage extends PageBase{

	public AddEmployeePage(WebDriver driver) {
		super(driver);
		
	}
	@FindBy(name="firstName")
	WebElement fnameTxt;
	
	@FindBy(name="middleName")
	WebElement mnameTxt;
	
	@FindBy(name="lastName")
	WebElement lnameTxt;
	
	@FindBy(css="#app > div.oxd-layout.orangehrm-upgrade-layout > div.oxd-layout-container > div.oxd-layout-context > div > div > form > div.orangehrm-employee-container > div.orangehrm-employee-form > div:nth-child(1) > div.oxd-grid-2.orangehrm-full-width-grid > div > div > div:nth-child(2) > input")
	WebElement empIdTxt;
	
	@FindBy(xpath="//*[@id=\"app\"]/div[1]/div[2]/div[2]/div/div/form/div[1]/div[2]/div[2]/div/label/span")
    WebElement createLoginDetailsCheckBox;
	
	@FindBy(xpath="//*[@id=\"app\"]/div[1]/div[2]/div[2]/div/div/form/div[1]/div[2]/div[3]/div/div[1]/div/div[2]/input")
	WebElement userNameTxt;
	
	@FindBy(xpath="//*[@id=\"app\"]/div[1]/div[2]/div[2]/div/div/form/div[1]/div[2]/div[4]/div/div[1]/div/div[2]/input")
	WebElement password;
	
	@FindBy(xpath="//*[@id=\"app\"]/div[1]/div[2]/div[2]/div/div/form/div[1]/div[2]/div[4]/div/div[2]/div/div[2]/input")
    WebElement confirmPassword;
	
	@FindBy(xpath="//*[@id=\"app\"]/div[1]/div[2]/div[2]/div/div/form/div[1]/div[2]/div[3]/div/div[2]/div/div[2]/div[1]/div[2]/div/label/span")
    WebElement statusEnabledCheckBox;
	
	@FindBy(xpath="//*[@id=\"app\"]/div[1]/div[2]/div[2]/div/div/form/div[1]/div[2]/div[3]/div/div[2]/div/div[2]/div[2]/div[2]/div/label/span")
    WebElement statusDisabledCheckBox;
	
	@FindBy(css="#app > div.oxd-layout.orangehrm-upgrade-layout > div.oxd-layout-container > div.oxd-layout-context > div > div > form > div.oxd-form-actions > button.oxd-button.oxd-button--medium.oxd-button--secondary.orangehrm-left-space")
	WebElement saveBtn;
	
	@FindBy(css="#app > div.oxd-layout.orangehrm-upgrade-layout > div.oxd-layout-container > div.oxd-layout-context > div > div > form > div.oxd-form-actions > button.oxd-button.oxd-button--medium.oxd-button--secondary.orangehrm-left-space")
	WebElement cancelBtn;
	
	@FindBy(xpath="//*[@id=\"app\"]/div[1]/div[2]/div[2]/div/div/h6")
	public WebElement addEmpMsg;
	public void adminCanAddEmployee() {
		fnameTxt.sendKeys("layla");
		mnameTxt.sendKeys("Ahmed");
		lnameTxt.sendKeys("Karam");		
		createLoginDetailsCheckBox.click();
		userNameTxt.sendKeys("layla");
		password.sendKeys("s123456");
		confirmPassword.sendKeys("s123456");
		statusEnabledCheckBox.click();
		saveBtn.click();
	}
	public void adminCannotAddEmployeeWithExistUsername() {
		fnameTxt.sendKeys("layla");
		mnameTxt.sendKeys("Ahmed");
		lnameTxt.sendKeys("Karam");		
		createLoginDetailsCheckBox.click();
		userNameTxt.sendKeys("layla");
		password.sendKeys("s123456");
		confirmPassword.sendKeys("s123456");
		statusEnabledCheckBox.click();
		saveBtn.click();
	}
}

