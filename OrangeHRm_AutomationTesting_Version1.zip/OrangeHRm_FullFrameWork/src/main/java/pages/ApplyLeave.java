package pages;

public class ApplyLeave {

}
