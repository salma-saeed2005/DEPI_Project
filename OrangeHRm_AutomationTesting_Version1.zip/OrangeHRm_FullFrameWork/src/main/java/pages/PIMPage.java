package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class PIMPage extends PageBase {

    public PIMPage(WebDriver driver) {
        super(driver);
    }
   
    @FindBy(linkText = "Add Employee") 
    WebElement addEmployeeBtn;
    @FindBy(xpath="//*[@id=\"app\"]/div[1]/div[1]/header/div[1]/div[1]/span/h6")
	public WebElement pimMsg;
    public void openAddEmployeePage() {
        addEmployeeBtn.click();
    }
}