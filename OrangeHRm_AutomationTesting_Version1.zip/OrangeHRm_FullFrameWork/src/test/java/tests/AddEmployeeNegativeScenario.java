package tests;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.Test;

import pages.DashboardPage;
import pages.LoginPage;
import pages.PIMPage;
import pages.AddEmployeePage;

public class AddEmployeeNegativeScenario extends TestBase {
    LoginPage loginObject;
    DashboardPage dashboardObject;
    PIMPage pimObject;
    AddEmployeePage addEmployeeObject;

    @Test
    public void testAddEmployee_happyPath() throws InterruptedException {
        loginObject = new LoginPage(driver);
        dashboardObject = new DashboardPage(driver);
        pimObject = new PIMPage(driver);
        addEmployeeObject = new AddEmployeePage(driver);

        
        loginObject.login("Admin", "admin123");

        Thread.sleep(2000);
        Assert.assertEquals(dashboardObject.dashboardMsg.getText(),"Dashboard"); 
        
        dashboardObject.openPIMPage();
        Thread.sleep(1000);
        Assert.assertEquals(pimObject.pimMsg.getText(),"PIM"); 
        
        pimObject.openAddEmployeePage();
        Thread.sleep(1000);
        Assert.assertEquals(addEmployeeObject.addEmpMsg.getText(),"Add Employee");  
         
        addEmployeeObject.adminCannotAddEmployeeWithExistUsername();

        
        Thread.sleep(2000);
        WebElement errorMsg = driver.findElement(By.cssSelector("#app > div.oxd-layout.orangehrm-upgrade-layout > div.oxd-layout-container > div.oxd-layout-context > div > div > form > div.orangehrm-employee-container > div.orangehrm-employee-form > div:nth-child(4) > div > div:nth-child(1) > div > span"));
        
		Assert.assertTrue(errorMsg.getText().contains("Username already exists"));
        
    }
}