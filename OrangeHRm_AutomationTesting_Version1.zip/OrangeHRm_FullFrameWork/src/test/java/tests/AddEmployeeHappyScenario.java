package tests;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.Test;

import pages.DashboardPage;
import pages.LoginPage;
import pages.PIMPage;
import pages.AddEmployeePage;

public class AddEmployeeHappyScenario extends TestBase {
    LoginPage loginObject;
    DashboardPage dashboardObject;
    PIMPage pimObject;
    AddEmployeePage addEmployeeObject;

    @Test
    public void testAddEmployee_happyPath() throws InterruptedException {
        loginObject = new LoginPage(driver);
        dashboardObject = new DashboardPage(driver);
        pimObject = new PIMPage(driver);
        addEmployeeObject = new AddEmployeePage(driver);

        
        loginObject.login("Admin", "admin123");

        Thread.sleep(2000);
        Assert.assertEquals(dashboardObject.dashboardMsg.getText(),"Dashboard"); 
        
        dashboardObject.openPIMPage();
        Thread.sleep(1000);
        Assert.assertEquals(pimObject.pimMsg.getText(),"PIM"); 
        
        pimObject.openAddEmployeePage();
        Thread.sleep(1000);
        Assert.assertEquals(addEmployeeObject.addEmpMsg.getText(),"Add Employee");  
         
        addEmployeeObject.adminCanAddEmployee();

        
        Thread.sleep(2000);
        WebElement heading = driver.findElement(By.xpath("//*[@id=\"app\"]/div[1]/div[2]/div[2]/div/div/div/div[2]/div[1]/h6"));
		Assert.assertEquals(heading.getText(), "Personal Details");
        
    }
}
