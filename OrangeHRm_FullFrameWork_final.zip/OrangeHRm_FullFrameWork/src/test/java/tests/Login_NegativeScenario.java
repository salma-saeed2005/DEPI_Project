package tests;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;
import pages.LoginPage;

import java.time.Duration;

public class Login_NegativeScenario extends TestBase {

    private void navigateAndWait() {
        driver.navigate().to(baseURL);
       
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.name("username")));
    }

    @Test(priority = 1)
    public void invalidUsernameAndPassword() {
        navigateAndWait();

        LoginPage loginPage = new LoginPage(driver);
        loginPage.login("moragab@", "123456");

        // Wait for the error message
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        WebElement errorMsg = wait.until(ExpectedConditions.visibilityOfElementLocated( By.cssSelector("p.oxd-alert-content-text")));

        String actualMsg = errorMsg.getText();
        Assert.assertEquals(actualMsg, "Invalid credentials");
    }

    @Test(priority = 2)
    public void blankUsername() {
        navigateAndWait();

        LoginPage loginPage = new LoginPage(driver);
        loginPage.login("", "admin123");

        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        WebElement errorMsg = wait.until(ExpectedConditions.visibilityOfElementLocated(
                By.cssSelector("span.oxd-input-field-error-message")
        ));

        String actualMsg = errorMsg.getText();
        Assert.assertEquals(actualMsg, "Required");
    }

    @Test(priority = 3)
    public void blankPassword() {
        navigateAndWait();

        LoginPage loginPage = new LoginPage(driver);
        loginPage.login("Admin", "");

        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        WebElement errorMsg = wait.until(ExpectedConditions.visibilityOfElementLocated(
                By.cssSelector("span.oxd-input-field-error-message")
        ));

        String actualMsg = errorMsg.getText();
        Assert.assertEquals(actualMsg, "Required");
    }
    
    
}


