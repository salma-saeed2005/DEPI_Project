package tests;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;
import pages.LoginPage;
import java.time.Duration;

public class Login_HappyScenario extends TestBase {

    @Test
    public void validUsernameAndPassword() {
        LoginPage loginPage = new LoginPage(driver);

        loginPage.login("Admin", "admin123");

        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        WebElement userMenu = wait.until(
            ExpectedConditions.visibilityOfElementLocated(By.className("oxd-userdropdown-name"))
        );

        Assert.assertTrue(userMenu.isDisplayed(), "Login failed!");
    }
}