package tests;

import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import pages.PageBase;
import pages.LoginPage;
import pages.PIMPage;
import pages.searchEmployee;

public class SearchEmployeeHappyScenario extends TestBase {

    private LoginPage loginPage;
    private PIMPage pimPage;
    private searchEmployee searchPage;

    @BeforeClass
    public void setupPages() {
        loginPage = new LoginPage(driver);
        pimPage = new PIMPage(driver);
        searchPage = new searchEmployee(driver);

        loginPage.login("Admin", "admin123");
    }

    @BeforeMethod
    public void openEmployeeList() {
        driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/pim/viewEmployeeList");
    }


    @Test
    public void searchByValidName() {
        searchPage.clearFields();
        searchPage.enterEmployeeName("John");
        searchPage.clickSearch();
        Assert.assertTrue(searchPage.hasResults() || searchPage.isNoRecordsMessage());
    }

    @Test
    public void searchByValidId() {
        searchPage.clearFields();
        searchPage.enterEmployeeId("0001");
        searchPage.clickSearch();
        Assert.assertTrue(searchPage.hasResults() || searchPage.isNoRecordsMessage());
    }

    
    @Test
    public void searchByValidIdAndName() {
        searchPage.clearFields();
        searchPage.enterEmployeeId("0303");
        searchPage.enterEmployeeName("John");
        searchPage.clickSearch();
        Assert.assertTrue(searchPage.hasResults() || searchPage.isNoRecordsMessage());
    }

    @Test
    public void searchWithEmptyFields() {
        searchPage.clearFields();
        searchPage.clickSearch();
        Assert.assertTrue(searchPage.hasResults() || searchPage.isNoRecordsMessage());
    }
}
