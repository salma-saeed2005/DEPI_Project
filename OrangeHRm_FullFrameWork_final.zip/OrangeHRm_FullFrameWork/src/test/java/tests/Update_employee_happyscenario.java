package tests;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.Test;

import pages.DashboardPage;
import pages.LoginPage;
import pages.PIMPage;
import pages.UpdateEmployee;
import pages.AddEmployeePage;

public class Update_employee_happyscenario extends TestBase {
	LoginPage loginObject;
	UpdateEmployee update_object;

    @Test
    public void test_update_employee_info() throws InterruptedException {
    	loginObject = new LoginPage(driver);
    	loginObject.login("Admin", "admin123");
    	Thread.sleep(2000);
    	
        update_object = new UpdateEmployee(driver);
        update_object.go_to_edit_page();
        
        Assert.assertEquals(update_object.edit_user.getText(), "Edit User");
        Thread.sleep(2000);
     
        update_object.update_info();
        
        Thread.sleep(2000);
  
    }
   
}
    