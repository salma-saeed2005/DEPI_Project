package tests;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.Test;

import pages.DashboardPage;
import pages.LoginPage;
import pages.PIMPage;
import pages.UpdateEmployee;
import pages.AddEmployeePage;

public class Update_employee_negativescenario extends TestBase {
	LoginPage loginObject;
	UpdateEmployee update_object;

    @Test
    public void test_update_employee_info_nonexisting_username() throws InterruptedException {
    	loginObject = new LoginPage(driver);
    	loginObject.login("Admin", "admin123");
    	Thread.sleep(2000);
    	
        update_object = new UpdateEmployee(driver);
        update_object.go_to_edit_page();
        update_object.test_with_invalid_username();
        
        Thread.sleep(2000);
        Assert.assertEquals(update_object.invalid_name.getText(), "Invalid");
        
  
    }
   
}
    