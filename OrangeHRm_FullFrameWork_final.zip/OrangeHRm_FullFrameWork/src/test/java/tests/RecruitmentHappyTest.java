package tests;

import org.testng.Assert;
import org.testng.annotations.Test;

import pages.DashboardPage;
import pages.LoginPage;
import pages.RecruitmentPage;

public class RecruitmentHappyTest extends TestBase {
	LoginPage loginObject;
    DashboardPage dashboardObject;
    @Test(priority = 1)
    public void adminCanAddCandidateSuccessfully() throws InterruptedException {
    	loginObject = new LoginPage(driver);
        dashboardObject = new DashboardPage(driver);
    	RecruitmentPage recruitmentPage = new RecruitmentPage(driver);
    	loginObject.login("Admin", "admin123");

        Thread.sleep(2000);
        Assert.assertEquals(dashboardObject.dashboardMsg.getText(),"Dashboard"); 
        recruitmentPage.addCandidateSuccessfully();
        
        Thread.sleep(2000); 
        
        Assert.assertTrue(recruitmentPage.successMsg.getText().contains("Success"),
                 "Successfully Saved");
    }
}