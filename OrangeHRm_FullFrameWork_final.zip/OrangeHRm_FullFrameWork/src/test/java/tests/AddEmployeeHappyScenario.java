package tests;

import java.awt.AWTException;
import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import data.LoadAddEmployeeHappyData;
import pages.DashboardPage;
import pages.LoginPage;
import pages.PIMPage;
import pages.AddEmployeePage;

public class AddEmployeeHappyScenario extends TestBase {
    LoginPage loginObject;
    DashboardPage dashboardObject;
    PIMPage pimObject;
    AddEmployeePage addEmployeeObject;
    @DataProvider (name="addEmployeeHappyData")
    public Object[][] getAddEmpHappyData() throws IOException{
    	LoadAddEmployeeHappyData addEmpData = new LoadAddEmployeeHappyData();
    	return addEmpData.getExcelData(); 
    }
    
    @Test(dataProvider = "addEmployeeHappyData")
    public void testAddEmployee_happyPath(String fname,String mname,String lname,String userName,String passWord,String confirmPassWord) throws InterruptedException, AWTException {
        loginObject = new LoginPage(driver);
        dashboardObject = new DashboardPage(driver);
        pimObject = new PIMPage(driver);
        addEmployeeObject = new AddEmployeePage(driver);

        
        loginObject.login("Admin", "admin123");

        Thread.sleep(2000);
        Assert.assertEquals(dashboardObject.dashboardMsg.getText(),"Dashboard"); 
        
        dashboardObject.openPIMPage();
        Thread.sleep(1000);
        Assert.assertEquals(pimObject.pimMsg.getText(),"PIM"); 
        
        pimObject.openAddEmployeePage();
        Thread.sleep(1000);
        Assert.assertEquals(addEmployeeObject.addEmpMsg.getText(),"Add Employee");  
         
        addEmployeeObject.adminCanAddEmployee(fname,mname,lname,userName,passWord,confirmPassWord);

        
        Thread.sleep(2000);
        WebElement heading = driver.findElement(By.xpath("//*[@id=\"app\"]/div[1]/div[2]/div[2]/div/div/div/div[2]/div[1]/h6"));
		Assert.assertEquals(heading.getText(), "Personal Details");
		
    }
}
