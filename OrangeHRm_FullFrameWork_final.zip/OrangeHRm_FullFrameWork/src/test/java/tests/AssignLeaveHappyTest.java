package tests;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.Test;
import pages.DashboardPage;
import pages.LoginPage;
import pages.LeavePage;
import pages.AssignLeavePage;

public class AssignLeaveHappyTest extends TestBase {
    LoginPage loginObject;
    DashboardPage dashboardObject;
    LeavePage leaveObject;
    AssignLeavePage assignLeaveObject;

    @Test
    public void testAssignLeave_happyPath() throws InterruptedException {
        loginObject = new LoginPage(driver);
        dashboardObject = new DashboardPage(driver);
        leaveObject =new LeavePage(driver);
        assignLeaveObject = new AssignLeavePage(driver);

        loginObject.login("Admin", "admin123");
        Thread.sleep(2000);
        Assert.assertEquals(dashboardObject.dashboardMsg.getText(), "Dashboard");

        dashboardObject.openLeavePage();
        Thread.sleep(1000);
        leaveObject.openAssignLeavePage();
        Thread.sleep(1000);
        
          
      
        assignLeaveObject.adminCanAssignLeave();
        Thread.sleep(2000);

        WebElement success = driver.findElement(By.xpath("//*[@id=\"oxd-toaster_1\"]"));
        String actualText = success.getText().replace("\r\n", "\n");
        String expectedText = "Success\nSuccessfully Saved\n×";
        Assert.assertEquals(actualText, expectedText);
    }
}