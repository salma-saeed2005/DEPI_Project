package tests;

import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import pages.PageBase;
import pages.LoginPage;
import pages.PIMPage;
import pages.searchEmployee;

public class SearchEmployeeNegativeScenario extends TestBase {

    private LoginPage loginPage;
    private PIMPage pimPage;
    private searchEmployee searchPage;

    @BeforeClass
    public void setupPages() {
        loginPage = new LoginPage(driver);
        pimPage = new PIMPage(driver);
        searchPage = new searchEmployee(driver);

        loginPage.login("Admin", "admin123");
    }

    @BeforeMethod
    public void openEmployeeList() {
        driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/pim/viewEmployeeList");
    }

    @Test
    public void searchInvalidName() {
        searchPage.clearFields();
        searchPage.enterEmployeeName("aaazzz");
        searchPage.clickSearch();
        Assert.assertTrue(searchPage.hasResults() || searchPage.isNoRecordsMessage());
    }

    @Test
    public void searchInvalidId() {
        searchPage.clearFields();
        searchPage.enterEmployeeId("999999");
        searchPage.clickSearch();
        Assert.assertTrue(searchPage.hasResults() || searchPage.isNoRecordsMessage());
    }

    @Test
    public void searchInvalidCombination() {
        searchPage.clearFields();
        searchPage.enterEmployeeId("123456");
        searchPage.enterEmployeeName("None");
        searchPage.clickSearch();
        Assert.assertTrue(searchPage.hasResults() || searchPage.isNoRecordsMessage());
    }

    @Test
    public void searchSpecialCharacters() {
        searchPage.clearFields();
        searchPage.enterEmployeeName("@#$%^&*");
        searchPage.clickSearch();
        Assert.assertTrue(searchPage.hasResults() || searchPage.isNoRecordsMessage());
    }
}
