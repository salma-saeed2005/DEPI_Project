package tests;

import java.awt.AWTException;
import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import data.LoadAddEmployeeHappyData;
import data.LoadAddEmployeeNegativeData;
import pages.DashboardPage;
import pages.LoginPage;
import pages.PIMPage;
import pages.AddEmployeePage;

public class AddEmployeeNegativeScenario extends TestBase {
    LoginPage loginObject;
    DashboardPage dashboardObject;
    PIMPage pimObject;
    AddEmployeePage addEmployeeObject;
    @DataProvider (name="addEmployeeNegativeData")
    public Object[][] getAddEmpHappyData() throws IOException{
    	LoadAddEmployeeNegativeData addEmpData = new LoadAddEmployeeNegativeData();
    	return addEmpData.getExcelData(); 
    }
    
    @Test(dataProvider = "addEmployeeNegativeData")
    
    public void testAddEmployee_negPath(String fname,String mname,String lname,String userName,String passWord,String confirmPassWord) throws InterruptedException, AWTException {
        loginObject = new LoginPage(driver);
        dashboardObject = new DashboardPage(driver);
        pimObject = new PIMPage(driver);
        addEmployeeObject = new AddEmployeePage(driver);

        
        loginObject.login("Admin", "admin123");

        Thread.sleep(2000);
        Assert.assertEquals(dashboardObject.dashboardMsg.getText(),"Dashboard"); 
        
        dashboardObject.openPIMPage();
        Thread.sleep(1000);
        Assert.assertEquals(pimObject.pimMsg.getText(),"PIM"); 
        
        pimObject.openAddEmployeePage();
        Thread.sleep(1000);
        Assert.assertEquals(addEmployeeObject.addEmpMsg.getText(),"Add Employee");  
         
        addEmployeeObject.adminCannotAddEmployeeWithExistUsername(fname,mname,lname,userName,passWord,confirmPassWord);

        
        Thread.sleep(2000);
        WebElement errorMsg = driver.findElement(By.cssSelector("#app > div.oxd-layout.orangehrm-upgrade-layout > div.oxd-layout-container > div.oxd-layout-context > div > div > form > div.orangehrm-employee-container > div.orangehrm-employee-form > div:nth-child(4) > div > div:nth-child(1) > div > span"));
        
		Assert.assertTrue(errorMsg.getText().contains("Username already exists"));
        
    }
}