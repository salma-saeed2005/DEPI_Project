package data;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class LoadAddEmployeeHappyData {
FileInputStream stream=null;

public FileInputStream getExcelFile() throws FileNotFoundException {
	String filePath=System.getProperty("user.dir")+"/src/test/java/Excel/addEmpHappy.xlsx";
	 return new FileInputStream(filePath);
}
public Object[][] getExcelData() throws IOException{
	stream=getExcelFile();
	XSSFWorkbook workBook=new XSSFWorkbook(stream);
	
	XSSFSheet addEmployeeSheet = workBook.getSheet("Sheet1");
	int nRows=addEmployeeSheet.getLastRowNum()+1;
	int nCols=6;
	Object [][] addEmployeeHappyData = new Object [nRows][nCols];
	for(int i =0; i<nRows;i++ ) {
		XSSFRow row = addEmployeeSheet.getRow(i);
		for (int j=0;j<nCols;j++) {
			addEmployeeHappyData[i][j]=row.getCell(j).toString();
			
		}
	}
	workBook.close();
	return addEmployeeHappyData; 
}
}
