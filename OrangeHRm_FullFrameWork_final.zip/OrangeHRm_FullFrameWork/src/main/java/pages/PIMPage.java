package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class PIMPage extends PageBase {

    public PIMPage(WebDriver driver) {
        super(driver);
    }
   
    @FindBy(linkText = "Add Employee") 
    WebElement addEmployeeBtn;
    @FindBy(xpath="//*[@id=\"app\"]/div[1]/div[1]/header/div[1]/div[1]/span/h6")
	public WebElement pimMsg;
    @FindBy(xpath="//*[@id=\"app\"]/div[1]/div[1]/header/div[1]/div[3]/ul/li/span/p")
    public WebElement dropDownMenu;
    @FindBy(linkText="Logout")
    public WebElement logoutBtn;
    @FindBy(xpath="//*[@id=\"app\"]/div[1]/div[1]/aside/nav/div[2]/ul/li[8]/a")
	public WebElement dashBoardBtn;
    public void openAddEmployeePage() {
        addEmployeeBtn.click();
    }
    public void logout() {
    	dropDownMenu.click();
		logoutBtn.click();  
    }
}