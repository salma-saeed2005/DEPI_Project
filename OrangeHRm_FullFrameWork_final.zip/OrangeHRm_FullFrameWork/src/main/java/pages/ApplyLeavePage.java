package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class ApplyLeavePage extends PageBase {

    public ApplyLeavePage(WebDriver driver) {
        super(driver);
    }

    @FindBy(xpath = "/html/body/div/div[1]/div[1]/header/div[2]/nav/ul/li/ul/div[1]/li/a")
    WebElement applyLeaveMenu;

    @FindBy(xpath = "/html/body/div/div[1]/div[2]/div[2]/div/div/form/div[1]/div/div[1]/div/div[2]/div/div")
    WebElement leaveTypeDropDown;

    @FindBy(xpath = "/html/body/div/div[1]/div[2]/div[2]/div/div/form/div[2]/div/div[1]/div/div[2]/div/div/input")
    WebElement fromDateTxt;

    @FindBy(xpath = "/html/body/div/div[1]/div[2]/div[2]/div/div/form/div[2]/div/div[2]/div/div[2]/div/div/input")
    WebElement toDateTxt;

    @FindBy(xpath = "/html/body/div/div[1]/div[2]/div[2]/div/div/form/div[3]/div/div/div/div[2]/textarea")
    WebElement commentTxt;

    @FindBy(xpath = "/html/body/div/div[1]/div[2]/div[2]/div/div/form/div[4]/button")
    WebElement applyBtn;
}