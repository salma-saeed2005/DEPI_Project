package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class UpdateEmployee extends PageBase {

    public UpdateEmployee(WebDriver driver) {
        super(driver);
    }

    @FindBy(xpath = "//*[@id=\"app\"]/div[1]/div[1]/aside/nav/div[2]/ul/li[1]/a/span")
    public WebElement admin_btn;

    @FindBy(xpath = "//*[@id=\"app\"]/div[1]/div[2]/div[2]/div/div[2]/div[3]/div/div[2]/div[1]/div/div[6]/div/button[2]")
    public WebElement edit_btn;

    @FindBy(xpath = "//*[@id=\"app\"]/div[1]/div[2]/div[2]/div/div/form/div[1]/div/div[1]/div/div[2]/div/div/div[2]/i")
    public WebElement roles_list;

    @FindBy(xpath = "//span[text()='ESS']")
    public WebElement role_ESS;

    @FindBy(xpath = "//*[@id=\"app\"]/div[1]/div[2]/div[2]/div/div/form/div[1]/div/div[2]/div/div[2]/div/div/input")
    public WebElement employee_name;

    @FindBy(xpath = "//*[@id=\"app\"]/div[1]/div[2]/div[2]/div/div/form/div[1]/div/div[3]/div/div[2]/div/div/div[2]/i")
    public WebElement status_list;

    @FindBy(xpath = "//span[text()='Disabled']")
    public WebElement status_disabled;

    @FindBy(xpath = "//*[@id=\"app\"]/div[1]/div[2]/div[2]/div/div/form/div[1]/div/div[4]/div/div[2]/input")
    public WebElement username;

    @FindBy(xpath = "//*[@id=\"app\"]/div[1]/div[2]/div[2]/div/div/form/div[1]/div/div[5]/div/div[2]/div/label")
    public WebElement change_password;

    @FindBy(xpath = "//*[@id=\"app\"]/div[1]/div[2]/div[2]/div/div/form/div[2]/div/div[1]/div/div[2]/input")
    public WebElement new_password;

    @FindBy(xpath = "//*[@id=\"app\"]/div[1]/div[2]/div[2]/div/div/form/div[2]/div/div[2]/div/div[2]/input")
    public WebElement confirm_password;

    @FindBy(xpath = "//*[@id=\"app\"]/div[1]/div[2]/div[2]/div/div/form/div[3]/button[2]")
    public WebElement save_btn;
    
    @FindBy(xpath = "//*[@id=\"app\"]/div[1]/div[2]/div[2]/div/div/h6")
    public WebElement edit_user;
    
    @FindBy(xpath = "//*[@id=\"app\"]/div[1]/div[2]/div[2]/div/div/form/div[1]/div/div[2]/div/span")
    public WebElement invalid_name;

    public void go_to_edit_page() {
        admin_btn.click();
        edit_btn.click();
    }

    public void update_info() throws InterruptedException {
        roles_list.click();      
        role_ESS.click();         

        //employee_name.clear();
        employee_name.click();
        employee_name.sendKeys(Keys.CONTROL + "a");
        employee_name.sendKeys(Keys.DELETE);
        employee_name.sendKeys("Salma Saeed");
        Thread.sleep(2000);
        
        status_list.click();       
        status_disabled.click(); 

        //username.clear();
        username.click();
        username.sendKeys(Keys.CONTROL + "a");
        username.sendKeys(Keys.DELETE);
        username.sendKeys("Salma2310");
        Thread.sleep(2000);
        
        change_password.click();

        new_password.sendKeys("a@XG5LzzTG5Fbs");
        confirm_password.sendKeys("a@XG5LzzTG5Fbs");
        Thread.sleep(2000);
        save_btn.click();
    }
    
    public void test_with_invalid_username () {
    	username.click();
        username.sendKeys(Keys.CONTROL + "a");
        username.sendKeys(Keys.DELETE);
    	username.sendKeys("this_user");
    	
    	change_password.click();
    	
    	new_password.sendKeys("salma123*");
    	confirm_password.sendKeys("salma123*");
    	save_btn.click();
    }
}
