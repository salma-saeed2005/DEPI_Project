package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class searchEmployee extends PageBase {

    public searchEmployee(WebDriver driver) {
        super(driver);
    }

    @FindBy(xpath = "//label[text()='Employee Id']/../following-sibling::div//input")
    WebElement employeeIdField;

    @FindBy(xpath = "//label[text()='Employee Name']/../following-sibling::div//input")
    WebElement employeeNameField;

    @FindBy(xpath = "//button[@type='submit']")
    WebElement searchButton;

    @FindBy(xpath = "//div[@class='oxd-table-body']")
    WebElement tableBody;

    @FindBy(id = "oxd-toaster_1")
    WebElement noRecordsToast;

    public void clearFields() {
        employeeIdField.clear();
        employeeNameField.clear();
    }

    public void enterEmployeeId(String id) {
        employeeIdField.sendKeys(id);
    }

    public void enterEmployeeName(String name) {
        employeeNameField.sendKeys(name);
    }

    public void clickSearch() {
        searchButton.click();
    }

    public boolean hasResults() {
        return tableBody.findElements(org.openqa.selenium.By.xpath(".//div[@role='row']")).size() > 0;
    }

    public boolean isNoRecordsMessage() {
        try {
            return noRecordsToast.getText().contains("No Records Found");
        } catch (Exception e) {
            return false;
        }
    }
}
