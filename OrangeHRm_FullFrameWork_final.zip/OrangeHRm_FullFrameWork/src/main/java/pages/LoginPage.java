package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class LoginPage extends PageBase {


    public LoginPage(WebDriver driver) {
        super(driver);
    }
;
    @FindBy(css = "input[name='username']")
    WebElement usernameInput;

    @FindBy(css = "input[name='password']")
    WebElement passwordInput;

    @FindBy(css = "button[type='submit']")
    WebElement loginBtn;

    @FindBy(css = "p.oxd-alert-content-text")
    WebElement invalidMsg;

    @FindBy(xpath = "(//span[@class='oxd-input-field-error-message'])[1]")
    WebElement usernameRequired;

    @FindBy(xpath = "(//span[@class='oxd-input-field-error-message'])[2]")
    WebElement passwordRequired;


    public void login(String user, String pass) {
        usernameInput.clear();
        usernameInput.sendKeys(user);

        passwordInput.clear();
        passwordInput.sendKeys(pass);

        loginBtn.click();
    }

    public String getInvalidMessage() {
        return invalidMsg.getText();
    }

    public String getUsernameRequired() {
        return usernameRequired.getText();
    }

    public String getPasswordRequired() {
        return passwordRequired.getText();
    }
    
    
    
    
    
    // logout page don't care
    public boolean isLoginPageDisplayed() {
        try {
            return loginBtn.isDisplayed();
        } catch (Exception e) {
            return false;
        }
    }

}
