package pages;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class AssignLeavePage extends PageBase {

    public AssignLeavePage(WebDriver driver) {
        super(driver);
    }

    @FindBy(xpath = "//*[@id=\"app\"]/div[1]/div[2]/div[2]/div/div/form/div[1]/div/div/div/div[2]/div/div/input")
    WebElement empNameTxt;
    @FindBy(xpath = "(//div[@role='option'])[1]")
    WebElement firstHint;
    
    @FindBy(xpath = "//label[text()='Leave Type']/following::div[contains(@class,'oxd-select-text')][1]")
    WebElement leaveTypeDropdown;


    @FindBy(xpath = "//span[contains(text(),'CAN - Personal')]")
    WebElement leaveTypePersonal;


    @FindBy(xpath = "//label[text()='From Date']/following::input[1]")
    WebElement fromDateTxt;
    @FindBy(xpath = "//label[text()='To Date']/following::input[1]")
    WebElement toDateTxt;


    @FindBy(xpath = "//button[contains(.,'Assign')]")
    WebElement assignBtn;

    @FindBy(xpath = "//*[@id=\"app\"]/div[3]/div/div/div/div[3]/button[2]")
    WebElement confirmBtn;
    @FindBy(xpath = "//*[@id=\"app\"]/div[1]/div[2]/div[2]/div/div/form/div[6]/button")
    public WebElement errorMsg;

    public WebElement assMsg;
    public void adminCanAssignLeave() throws InterruptedException {
    	empNameTxt.click();
        empNameTxt.sendKeys("A");
        Thread.sleep(1500);
        firstHint.click();

        leaveTypeDropdown.click();
        Thread.sleep(1000); 
        leaveTypePersonal.click();

        fromDateTxt.click();
        fromDateTxt.clear();
        fromDateTxt.sendKeys("2025-11-4");
        fromDateTxt.sendKeys(Keys.TAB);
        assignBtn.click();
        confirmBtn.click();
        
    }


       public void adminCannotAssignLeaveTwice() throws InterruptedException {
    	   empNameTxt.click();
           empNameTxt.sendKeys("A");
           Thread.sleep(1500);
           firstHint.click();
           leaveTypeDropdown.click();
           Thread.sleep(1000);            
           leaveTypePersonal.click();
           fromDateTxt.click();
           fromDateTxt.clear();
           fromDateTxt.sendKeys("2025-11-4");
           fromDateTxt.sendKeys(Keys.TAB);
           assignBtn.click();
           confirmBtn.click();
           assignBtn.click();
           confirmBtn.click();
       }
       public void adminCannotAssignLeavewith_Non_Working_Day() throws InterruptedException {
    	   empNameTxt.click();
           empNameTxt.sendKeys("A");
           Thread.sleep(1500);
           firstHint.click();
           leaveTypeDropdown.click();
           Thread.sleep(1000);            
           leaveTypePersonal.click();
           fromDateTxt.click();
           fromDateTxt.clear();
           fromDateTxt.sendKeys("2025-11-11");
           fromDateTxt.sendKeys(Keys.TAB);
           assignBtn.click();
           confirmBtn.click();
           assignBtn.click();
           confirmBtn.click();
       }
}