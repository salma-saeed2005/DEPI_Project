package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class RecruitmentPage extends PageBase {

    public RecruitmentPage(WebDriver driver) {
        super(driver);
    }


    @FindBy(xpath = "//span[text()='Recruitment']")
    WebElement recruitmentMenu;

    @FindBy(xpath = "//button[normalize-space()='Add']")
    WebElement addButton;

    @FindBy(name = "firstName")
    WebElement firstNameTxt;

    @FindBy(name = "lastName") 
    WebElement lastNameTxt;

    @FindBy(xpath = "//label[text()='Email']/../following-sibling::div//input")
    WebElement emailTxt;

    @FindBy(xpath = "//button[@type='submit']")
    WebElement saveBtn;

    @FindBy(xpath = "//div[contains(@class, 'oxd-toast-content')]")
    public WebElement successMsg;

    @FindBy(xpath = "//span[contains(@class, 'oxd-input-field-error-message')]")
    public WebElement requiredErrorMsg;
    
  
    public void addCandidateSuccessfully() {
        recruitmentMenu.click();
        addButton.click();
        
        firstNameTxt.clear();
        firstNameTxt.sendKeys("Mariem"); // From your test case
        
        lastNameTxt.clear();
        lastNameTxt.sendKeys("User"); // From your test case
        
        emailTxt.clear();
        emailTxt.sendKeys("mariem@example.com"); // From your test case
        
        saveBtn.click();
    }

   
    public void addCandidateWithMissingFields() {
        recruitmentMenu.click();
        addButton.click();
        saveBtn.click();
    }
}