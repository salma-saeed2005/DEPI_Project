package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class LeavePage extends PageBase {
	public LeavePage(WebDriver driver) {
        super(driver);
    }
   
    @FindBy(linkText = "Assign Leave") 
    WebElement assignLeavebtn;
    @FindBy(xpath="//*[@id=\"app\"]/div[1]/div[1]/aside/nav/div[2]/ul/li[3]/a/span")
	public WebElement leaveMsg;
    public void openAssignLeavePage() {
    	assignLeavebtn.click();
    }
	public void openEntitlementPage() {
		
		
	}
}